#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int n = 12;

void swap(int *x, int *y)
{
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

void permute(int grid[n][n], int best[n], int *highest, int a[n], int l, int r, int *perms)
{
    int i;
    if (l == r)
    {
        int tempHigh = 0;
        for (int k = 0; k < n; k++)
        {
            tempHigh += grid[a[k]][k];
        }
        if (tempHigh >= *highest)
        {
            *highest = tempHigh;
            for (int k = 0; k < n; k++)
            {
                best[k] = a[k];
            }
        }
        (*perms)++;
    }
    else
    {
        for (i = l; i <= r; i++)
        {
            swap((a + l), (a + i));
            permute(grid, best, highest, a, l + 1, r, perms);
            swap((a + l), (a + i)); // backtrack
        }
    }
}

int main()
{

    int grid[n][n];
    int best[n];
    int highest = 0;
    int workers[n];
    int i, j = 0;
    int num;
    char filename[256];

    printf("Brute force program for assignment problem\n");
    printf("Enter the file name : ");
    scanf("%s", filename);
    FILE *file = fopen(filename, "r");
    for (i = 0; i < n; i++)
    {
        workers[i] = i;
        for (j = 0; j < n; j++)
        {
            fscanf(file, "%d", &num);
            grid[i][j] = num;
        }
    }
    fclose(file);
    int perms = 0;
    clock_t begin = clock();
    permute(grid, best, &highest, workers, 0, n - 1, &perms);
    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("The number of all the possible assignments : %d\n", perms);
    printf("The person - job assignment selected : \n");
    for (i = 0; i < n; i++)
    {
        printf("%d ", best[i] + 1);
    }
    printf("\n");
    printf("The total value : %d\n", highest);
    printf("Execution time = %f ms\n", time*1000);
    return 0;
}