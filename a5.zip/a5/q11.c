#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>


int comp(const void *a, const void *b)
{
    return *((int *)a) - *((int *)b);
}

int countSubsets(int arr[], int size, int sum, int i)
{
    if (sum == 0)
    {
        return 1;
    }

    if (sum < 0 || i == size)
    {
        return 0;
    }

    return countSubsets(arr, size, sum - arr[i], i + 1) + countSubsets(arr, size, sum, i + 1);
}

int main()
{
    printf("Brute force program for subset sum problem\n");
    printf("Enter the file name and subset sum: ");
    int sum = 0;
    int n = 25;
    char filename[256] = "data_A5_Q1_1.txt";
    scanf("%s %d", filename, &sum);
    int array[25];
    FILE *file = fopen(filename, "r");
    int i = 0;
    int j = 0;
    fscanf(file, "%d", &i);
    while (!feof(file))
    {
        array[j] = i;
        j++;
        fscanf(file, "%d", &i);
    }
    fclose(file);
    qsort(array, 25, sizeof(int), comp);
    int count = 0;
    clock_t begin = clock();
    count = countSubsets(array, n, sum, 0);

    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Number of all the subsets: %d\n", (int)pow(2, n));
    printf("Number of the subsets whose sums are %d: %d\n", sum, count);
    printf("Execution time = %f ms\n", time*1000);
    return 0;
}
