#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int comp(const void *a, const void *b)
{
    return *((int *)a) - *((int *)b);
}
void find(int array[], int n, int sum, int index, int subset[], int size, int target, int *count, int *end)
{
    if (sum == target)
    {
        (*count)++;
    }
    else if (sum < target && index < n)
    {
        subset[size] = array[index];
        find(array, n, sum + array[index], index + 1, subset, size + 1, target, count, end);
        find(array, n, sum, index + 1, subset, size, target, count, end);
    }
    else
    {
        (*end)++;
    }
}

int main()
{
    char filename[256] = "q1.txt";
    int n = 25;
    int array[n];
    int target = 1200;
    printf("Backtracking program for subset sum problem\n");
    printf("Enter the file name and subset sum: ");
    scanf("%s %d", filename, &target);

    FILE *file = fopen(filename, "r");
    int i = 0;
    int j = 0;
    fscanf(file, "%d", &i);
    while (!feof(file))
    {
        array[j] = i;
        j++;
        fscanf(file, "%d", &i);
    }
    fclose(file);
    qsort(array, 25, sizeof(int), comp);
    int subset[25] = {0};
    int count = 0;
    int ends = 0;
    clock_t begin = clock();
    find(array, n, 0, 0, subset, 0, target, &count, &ends);
    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Number of dead ends: %d\n", ends);
    printf("Number of the subsets whose sums are %d: %d\n", target, count);
    printf("Execution time = %f ms\n", time * 1000);
    return 0;
}
