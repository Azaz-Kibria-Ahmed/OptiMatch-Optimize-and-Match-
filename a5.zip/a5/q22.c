#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int n = 12;

int notInList(int list[n], int x)
{
    for (int i = 0; i < n; i++)
    {
        // printf("%d ", list[i]);
        if (list[i] == x)
        {
            // printf("\njob %d alsready assigned\n", x + 1);
            return 0;
        }
    }
    // printf("\n");
    return 1;
}
void printRow(int row[n])
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", row[i]);
    }
    printf("\n");
}
void addList(int list[n], int ji)
{
    for (int i = 0; i < n; i++)
    {
        if (list[i] == -1)
        {
            list[i] = ji;
            return;
        }
    }
}

int getNextCost(int row[n], int thisJob, int assigned[n])
{
    int low = 0;
    // printf("in nextCost row\n");
    // printRow(row);
    // printf("in nextCost assigned\n");
    // printRow(assigned);
    for (int i = 0; i < n; i++)
    {
        if (notInList(assigned, i) == 1 && i != thisJob && row[i] > low) /// change thisssssss
        {
            low = row[i];
        }
    }
    return low;
}

int getFirstUpper(int row[n], int assigned[n])
{
    int upper = 0;
    for (int i = 0; i < n; i++)
    {
        if (notInList(assigned, i) && row[i] > upper) // change thissss
        {
            upper = row[i];
        }
    }
    return upper;
}

int getUpperBound(int grid[n][n], int person, int job, int assigned[n])
{
    int upper = grid[person][job];
    // printf("first upper %d\n", upper);
    int assignedTotal = 0;
    // printf("assigned jobs\n");
    for (int i = 0; i < n; i++)
    {
        // printf("%d ", assigned[i] + 1);s
    }
    // printf("\n");
    // printf("\nruinning total\n");

    for (int i = 0; i < person; i++)
    {
        // printf("assigned costs %d\n", grid[i][assigned[i]]);
        assignedTotal += grid[i][assigned[i]];
    }
    // printf("assigned total %d\n", assignedTotal);
    upper += assignedTotal;
    // printf("final upper %d\n", upper);
    // fgetc(stdin);

    for (int j = person + 1; j < n; j++)
    {
        int row[n];
        for (int i = 0; i < n; i++)
            row[i] = grid[j][i];

        int nextCost = getNextCost(row, job, assigned);
        // printf("next cost %d\n", nextCost);
        // fgetc(stdin);
        upper += nextCost;
    }
    return upper;
}

void assign(int grid[n][n], int p, int j, int best[n])
{
    int assigned[n];
    for (int i = 0; i < n; i++)
        assigned[i] = -1;
    int assignedJob = 0;
    int high;
    // loop over persons
    for (int pi = 0; pi < n; pi++)
    {
        high = 0;
        for (int ji = 0; ji < n; ji++)
        {
            if (notInList(assigned, ji) == 1)
            {

                int upperforThisJob = getUpperBound(grid, pi, ji, assigned);
                // printf("upperB %d\n", upperforThisJob);
                // fgetc(stdin);
                if (upperforThisJob > high) /// change this!!!!
                {
                    assignedJob = ji;
                    high = upperforThisJob;
                }
            }
        }

        assigned[pi] = assignedJob;
        printf("max upper bound %d\n", high);
        // printf("job %d assigned to P %d\n\n", assigned[pi] + 1, pi + 1);
    }
    printf("assignment\n");
    for (int i = 0; i < n; i++)
        printf("%d ", assigned[i] + 1);
    printf("\n");
    printf("max total value %d\n", high);
}

int main()
{
    int grid[n][n];
    int best[n];
    // int highest = 0;
    int i, j = 0;
    int num;
    char filename[256] = "q2.txt";

    printf("Brute force program for assignment problem\n");
    printf("Enter the file name : ");
    scanf("%s", filename);
    FILE *file = fopen(filename, "r");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            fscanf(file, "%d", &num);
            grid[i][j] = num;
        }
    }
    fclose(file);
    clock_t begin = clock();
    assign(grid, n, n, best);
    clock_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Execution time = %f ms\n", time * 1000);

    return 0;
}